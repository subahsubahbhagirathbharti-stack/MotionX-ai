# MOTION X AI

Android starter project for a Kinetic Typography / Script-to-Video app.

## Current MVP features
- Premium dark emerald/teal Compose UI
- Script input and animated typography preview
- Audio file picker (MP3/WAV/M4A selection)
- Android system Text-to-Speech sample playback
- Settings screen and GitHub Actions debug APK workflow

## Important current limitations
This starter does **not yet** transcribe selected audio, call Gemini/Groq, generate AI video scenes, or render/export MP4. Those require the next implementation stages and, for cloud AI, provider keys/quotas plus a secure backend. Never commit API keys to this repository or embed private keys in the APK.

## Build
GitHub Actions runs on pushes to `main`/`master`, or manually via Actions > Build MotionX AI APK > Run workflow. Download `MotionX-AI-debug-apk` from the completed run's Artifacts section.

Package: `com.motionx.ai`
Min Android: 8.0 (API 26)
Compile SDK: 35
JDK: 17
Gradle: 8.9
