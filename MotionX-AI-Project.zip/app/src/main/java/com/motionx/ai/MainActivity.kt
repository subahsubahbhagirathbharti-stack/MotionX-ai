package com.motionx.ai

import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Bg = Color(0xFF06110F)
private val Panel = Color(0xFF0D211C)
private val Green = Color(0xFF00D6A0)
private val Blue = Color(0xFF35BDF5)
private val Muted = Color(0xFF8AB6A9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MotionXApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MotionXApp() {
    val context = LocalContext.current
    var page by remember { mutableStateOf("Home") }
    var script by remember { mutableStateOf("आज से अपनी कहानी खुद लिखो।\\nहर छोटा कदम एक नई शुरुआत है।\\nअपने सपनों को गति दो!") }
    var audioName by remember { mutableStateOf("कोई ऑडियो चुना नहीं गया") }
    var selectedLanguage by remember { mutableStateOf("Hindi") }
    var previewText by remember { mutableStateOf("अपनी कहानी को गति दो") }
    var ttsStatus by remember { mutableStateOf("फोन की उपलब्ध Text-to-Speech आवाज़ इस्तेमाल होगी।") }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(Unit) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
        }
        onDispose { tts?.stop(); tts?.shutdown() }
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            audioName = uri.lastPathSegment ?: "Audio file selected"
            ttsStatus = "ऑडियो चुना गया है। इस MVP में ऑडियो transcription अभी उपलब्ध नहीं है।"
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green, secondary = Blue, background = Bg,
            surface = Panel, onPrimary = Color.Black, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = { Text("MOTION X AI", fontWeight = FontWeight.Black, letterSpacing = 1.2.sp) },
                    actions = {
                        IconButton(onClick = { page = "Settings" }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Green)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = Green)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF091915), contentColor = Green) {
                    listOf("Home", "Create", "Voice", "Settings").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "Home" -> Icons.Default.Home
                                        "Create" -> Icons.Default.Movie
                                        "Voice" -> Icons.Default.RecordVoiceOver
                                        else -> Icons.Default.Settings
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green, selectedTextColor = Green,
                                indicatorColor = Color(0xFF123A30),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            AnimatedContent(page, modifier = Modifier.padding(padding), label = "page") { current ->
                when (current) {
                    "Create" -> CreateScreen(
                        script, { script = it }, previewText, { previewText = it },
                        onPreview = { previewText = script.lines().firstOrNull { line -> line.isNotBlank() } ?: "MOTION X AI" }
                    )
                    "Voice" -> VoiceScreen(
                        audioName, { audioPicker.launch(arrayOf("audio/*")) },
                        ttsStatus, { ttsStatus = it },
                        onSpeak = {
                            val text = script.trim().ifBlank { "नमस्ते, Motion X AI में आपका स्वागत है" }
                            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "motionx-voice")
                            ttsStatus = "फोन की TTS आवाज़ चलाने का अनुरोध भेजा गया।"
                        }
                    )
                    "Settings" -> SettingsScreen(selectedLanguage, { selectedLanguage = it })
                    else -> HomeScreen(
                        onCreate = { page = "Create" },
                        onVoice = { page = "Voice" },
                        onSettings = { page = "Settings" }
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onCreate: () -> Unit, onVoice: () -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            Modifier.fillMaxWidth().height(190.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF064D3D), Color(0xFF092A3B), Bg)), RoundedCornerShape(28.dp))
                .padding(20.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("CREATE WITHOUT LIMITS", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Your words.\nYour motion.", fontSize = 32.sp, lineHeight = 36.sp, fontWeight = FontWeight.Black)
                Text("Kinetic typography • Voice • Captions", color = Muted, fontSize = 12.sp)
            }
        }
        Text("AI CREATION STUDIO", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        FeatureCard("Kinetic Typography", "स्क्रिप्ट से animated text preview", Icons.Default.TextFields, Green, onCreate)
        FeatureCard("Script to Video", "सीन के हिसाब से अपनी स्क्रिप्ट तैयार करें", Icons.Default.Movie, Blue, onCreate)
        FeatureCard("Text to Voice", "फोन की उपलब्ध TTS आवाज़ से सुनें", Icons.Default.RecordVoiceOver, Color(0xFFFFB547), onVoice)
        FeatureCard("Auto Captions", "Caption workflow का शुरुआती सेक्शन", Icons.Default.ClosedCaption, Color(0xFFB69CFF), onCreate)
        Text("MVP BUILD • More tools will be added in later versions", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp))
            .border(1.dp, tint.copy(alpha = .45f), RoundedCornerShape(20.dp))
            .clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).background(tint.copy(alpha = .13f), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = tint)
        }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Muted)
    }
}

@Composable
fun CreateScreen(script: String, onScript: (String) -> Unit, preview: String, onPreview: (String) -> Unit, onGenerate: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(0.98f, 1.02f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "scale")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Create your video", fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text("अपनी स्क्रिप्ट लिखो और animated typography preview देखो।", color = Muted)
        OutlinedTextField(
            value = script, onValueChange = onScript, modifier = Modifier.fillMaxWidth().height(190.dp),
            label = { Text("अपनी स्क्रिप्ट") }, placeholder = { Text("यहाँ अपनी कहानी लिखें...") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Green, unfocusedBorderColor = Muted,
                focusedLabelColor = Green, cursorColor = Green
            )
        )
        Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null)
            Spacer(Modifier.width(8.dp)); Text("Generate text preview", color = Color.Black, fontWeight = FontWeight.Bold)
        }
        Text("LIVE TYPOGRAPHY PREVIEW", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Box(
            Modifier.fillMaxWidth().height(230.dp).scale(scale)
                .background(Brush.linearGradient(listOf(Color(0xFF073D32), Color(0xFF102A48), Color(0xFF090F13))), RoundedCornerShape(24.dp))
                .border(1.dp, Green.copy(alpha = .6f), RoundedCornerShape(24.dp)).padding(22.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(preview, fontSize = 29.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, color = Color.White, lineHeight = 36.sp)
        }
        Text("नोट: यह अभी preview है। MP4 rendering और AI scene generation अगले build चरण में जोड़े जाएँगे।", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun VoiceScreen(audioName: String, onPick: () -> Unit, status: String, onStatus: (String) -> Unit, onSpeak: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Voice Studio", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("ऑडियो चुनें या अपनी स्क्रिप्ट फोन की TTS आवाज़ में सुनें।", color = Muted)
        OutlinedButton(onClick = onPick, modifier = Modifier.fillMaxWidth().height(110.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Green)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.AudioFile, contentDescription = null, modifier = Modifier.size(30.dp))
                Text("Pick audio file", fontWeight = FontWeight.Bold)
                Text("MP3 • WAV • M4A", color = Muted, fontSize = 11.sp)
            }
        }
        Text(audioName, color = Muted, fontSize = 12.sp)
        Button(onClick = onSpeak, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
            Text("Speak sample script", color = Color.Black, fontWeight = FontWeight.Bold)
        }
        Text(status, color = Muted, fontSize = 12.sp)
        Text("यह फोन की installed Text-to-Speech engine पर निर्भर है; Gemini voice API अभी कनेक्ट नहीं है।", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun SettingsScreen(language: String, onLanguage: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("App preferences", color = Muted)
        Text("Preview language", fontWeight = FontWeight.Bold)
        listOf("Hindi", "English", "Hinglish").forEach { option ->
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onLanguage(option) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(option, Modifier.weight(1f))
                if (language == option) Icon(Icons.Default.CheckCircle, contentDescription = "Selected", tint = Green)
            }
        }
        Text("API keys इस शुरुआती build में store नहीं होतीं। असली API integration के लिए सुरक्षित backend और usage limits की सेटिंग अगले चरण में होगी।", color = Muted, fontSize = 12.sp)
        Text("MOTION X AI • Version 1.0 MVP", color = Green, fontWeight = FontWeight.Bold)
    }
}
